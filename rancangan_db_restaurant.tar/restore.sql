--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.transaksi DROP CONSTRAINT transaksi_pkey;
ALTER TABLE ONLY public.tb_user DROP CONSTRAINT tb_user_pkey;
ALTER TABLE ONLY public.tb_order DROP CONSTRAINT tb_order_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.masakan DROP CONSTRAINT masakan_pkey;
ALTER TABLE ONLY public.detail_order DROP CONSTRAINT detail_order_pkey;
DROP TABLE public.transaksi;
DROP TABLE public.tb_user;
DROP TABLE public.tb_order;
DROP TABLE public.tb_level;
DROP TABLE public.masakan;
DROP TABLE public.detail_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order character varying(20) NOT NULL,
    id_order character varying(20),
    id_masakan character varying(20),
    keterangan character varying(50),
    status_detail_order character varying(10)
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE masakan (
    id_masakan character varying(20) NOT NULL,
    nama_masakan character varying(20),
    harga integer,
    status_masakan character varying(20)
);


ALTER TABLE masakan OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(20) NOT NULL,
    nama_level character varying(20)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_order (
    id_order character varying(20) NOT NULL,
    no_meja character varying(20),
    tanggal date,
    id_user character varying(20),
    keterangan character varying(50),
    status_order character varying(10)
);


ALTER TABLE tb_order OWNER TO postgres;

--
-- Name: tb_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_user (
    id_user character varying(20) NOT NULL,
    username character varying(20),
    password character varying(20),
    nama_user character varying(50),
    id_level character varying(20)
);


ALTER TABLE tb_user OWNER TO postgres;

--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi character varying(20) NOT NULL,
    id_user character varying(20),
    id_order character varying(20),
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2825.dat';

--
-- Data for Name: masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2826.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2824.dat';

--
-- Data for Name: tb_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2823.dat';

--
-- Data for Name: tb_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_user (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY tb_user (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2822.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2821.dat';

--
-- Name: detail_order detail_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order
    ADD CONSTRAINT detail_order_pkey PRIMARY KEY (id_detail_order);


--
-- Name: masakan masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY masakan
    ADD CONSTRAINT masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_order tb_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_order
    ADD CONSTRAINT tb_order_pkey PRIMARY KEY (id_order);


--
-- Name: tb_user tb_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_user
    ADD CONSTRAINT tb_user_pkey PRIMARY KEY (id_user);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- PostgreSQL database dump complete
--

